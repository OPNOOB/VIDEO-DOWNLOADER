import {
  Bolt,
  DownloadCloud,
  FileAudio,
  Film,
  Globe,
  Lock,
  Palette,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Wand2,
  Zap,
} from "lucide-react";
import { useInView } from "../hooks/useInView";

const FEATURES = [
  {
    icon: Bolt,
    title: "Blazing fast",
    desc: "Downloads start in seconds — our edge network processes your video the moment you paste a link.",
    accent: "from-amber-400 to-orange-500",
  },
  {
    icon: Film,
    title: "Up to 4K Ultra HD",
    desc: "Preserve every detail. Grab videos in their highest available quality — 4K, 1080p, 720p, and more.",
    accent: "from-violet-400 to-fuchsia-500",
  },
  {
    icon: FileAudio,
    title: "Audio extraction",
    desc: "Need just the sound? Export crystal‑clear MP3 or M4A audio at up to 320kbps.",
    accent: "from-emerald-400 to-teal-500",
  },
  {
    icon: ShieldCheck,
    title: "No watermarks",
    desc: "We remove the TikTok watermark automatically — save clean, shareable videos every time.",
    accent: "from-cyan-400 to-sky-500",
  },
  {
    icon: Globe,
    title: "All major platforms",
    desc: "YouTube, Shorts, Reels, TikTok, and more. One tool for every short‑form video you love.",
    accent: "from-pink-400 to-rose-500",
  },
  {
    icon: Lock,
    title: "Private by design",
    desc: "We never store your links or downloads. Everything happens in memory and is wiped instantly.",
    accent: "from-slate-300 to-zinc-400",
  },
  {
    icon: Wand2,
    title: "Bulk downloads",
    desc: "Paste a full YouTube playlist — Snatch will queue and download every video for you.",
    accent: "from-indigo-400 to-violet-500",
  },
  {
    icon: Smartphone,
    title: "Works everywhere",
    desc: "iPhone, Android, Mac, Windows — a mobile‑first experience that just works in your browser.",
    accent: "from-fuchsia-400 to-pink-500",
  },
  {
    icon: DownloadCloud,
    title: "Unlimited, free tier",
    desc: "Download as many videos as you want. Upgrade only if you want faster servers and 4K defaults.",
    accent: "from-sky-400 to-cyan-500",
  },
  {
    icon: Palette,
    title: "Captions & subtitles",
    desc: "Grab SRT or VTT subtitle files alongside your video — perfect for translations and editing.",
    accent: "from-yellow-400 to-amber-500",
  },
  {
    icon: Zap,
    title: "No sign‑up needed",
    desc: "Just paste and go. We believe in zero friction — your first download is three clicks away.",
    accent: "from-lime-400 to-emerald-500",
  },
  {
    icon: Sparkles,
    title: "Pro features",
    desc: "Unlock priority servers, 8K downloads, and cloud history with Snatch Pro — $4/month.",
    accent: "from-rose-400 to-pink-500",
  },
];

export function Features() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <section id="features" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-medium uppercase tracking-widest text-zinc-400">
            <Sparkles className="h-3 w-3 text-fuchsia-400" />
            Features
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-white sm:text-5xl">
            Everything you need.{" "}
            <span className="text-gradient">Nothing you don't.</span>
          </h2>
          <p className="mt-4 text-base text-zinc-400 sm:text-lg">
            Built by a team of video nerds who got tired of sketchy downloader sites.
            Here's what we shipped instead.
          </p>
        </div>

        <div
          ref={ref}
          className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
        >
          {FEATURES.map((f, idx) => (
            <div
              key={f.title}
              className={`group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02] p-6 transition hover:border-white/20 hover:bg-white/[0.04] ${
                inView ? "fade-up" : "opacity-0"
              }`}
              style={{ animationDelay: `${Math.min(idx * 60, 600)}ms` }}
            >
              <div
                className={`absolute -top-12 -right-12 h-40 w-40 rounded-full bg-gradient-to-br ${f.accent} opacity-0 blur-3xl transition group-hover:opacity-20`}
              />
              <div
                className={`inline-grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br ${f.accent} shadow-lg`}
              >
                <f.icon className="h-5 w-5 text-white" />
              </div>
              <h3 className="mt-4 text-base font-semibold text-white">{f.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-zinc-400">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
