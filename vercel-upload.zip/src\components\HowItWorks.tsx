import { ClipboardPaste, Download, Play, Settings } from "lucide-react";
import { useInView } from "../hooks/useInView";

const STEPS = [
  {
    num: "01",
    icon: ClipboardPaste,
    title: "Paste the link",
    desc: "Copy the URL from YouTube, Instagram, or TikTok and paste it into the input above.",
  },
  {
    num: "02",
    icon: Play,
    title: "We analyze it",
    desc: "Snatch fetches metadata, thumbnails, and every available quality from the source.",
  },
  {
    num: "03",
    icon: Settings,
    title: "Pick your format",
    desc: "Choose MP4, MP3, 4K, 1080p, or audio only. We'll even strip watermarks for you.",
  },
  {
    num: "04",
    icon: Download,
    title: "Download instantly",
    desc: "Hit download — your file lands in your Downloads folder in seconds, ready to share.",
  },
];

export function HowItWorks() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <section id="how" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-medium uppercase tracking-widest text-zinc-400">
            How it works
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-white sm:text-5xl">
            From link to file in <span className="text-gradient">under 10 seconds</span>.
          </h2>
          <p className="mt-4 text-base text-zinc-400 sm:text-lg">
            No extensions. No apps to install. No confusing menus.
          </p>
        </div>

        <div ref={ref} className="relative mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {/* Connecting line */}
          <div className="pointer-events-none absolute inset-x-10 top-12 hidden h-px bg-gradient-to-r from-transparent via-white/15 to-transparent lg:block" />

          {STEPS.map((s, idx) => (
            <div
              key={s.num}
              className={`relative ${inView ? "fade-up" : "opacity-0"}`}
              style={{ animationDelay: `${idx * 120}ms` }}
            >
              <div className="relative z-10 mx-auto grid h-24 w-24 place-items-center rounded-full border border-white/10 bg-[#0a0a12]">
                <div className="absolute inset-1 rounded-full bg-gradient-to-br from-violet-500/20 via-fuchsia-500/10 to-cyan-500/20" />
                <s.icon className="relative h-8 w-8 text-white" />
                <span className="absolute -top-1 -right-1 grid h-7 w-7 place-items-center rounded-full border border-white/20 bg-gradient-to-br from-violet-500 to-fuchsia-500 text-xs font-bold text-white shadow-lg">
                  {s.num}
                </span>
              </div>
              <div className="mt-5 text-center">
                <h3 className="text-base font-semibold text-white">{s.title}</h3>
                <p className="mt-1.5 text-sm text-zinc-400">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
