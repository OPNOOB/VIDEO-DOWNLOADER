import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import {
  ArrowDown,
  Check,
  Clock,
  Copy,
  Download,
  Eye,
  Film,
  Loader2,
  Link2,
  Music,
  Sparkles,
  AlertTriangle,
  X,
  FileVideo,
} from "lucide-react";
import { PLATFORMS, detectPlatform } from "../utils/platforms";
import { PlatformIcon } from "./Icons";
import {
  fetchMetadata,
  startDownload,
  pollJob,
  getFileUrl,
  triggerBrowserDownload,
  formatBytes,
  formatViews,
  type VideoMeta,
  type DownloadJob,
  type VideoFormat,
} from "../lib/api";

type Phase = "idle" | "fetching-meta" | "preview" | "downloading" | "done";

const EXAMPLES = [
  "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  "https://www.instagram.com/reel/C1Xz9vA",
  "https://www.tiktok.com/@tiktok/video/7000000000000000000",
];

export function Downloader() {
  const [url, setUrl] = useState("");
  const [phase, setPhase] = useState<Phase>("idle");
  const [meta, setMeta] = useState<VideoMeta | null>(null);
  const [selectedQuality, setSelectedQuality] = useState("1080");
  const [error, setError] = useState<string | null>(null);
  const [job, setJob] = useState<DownloadJob | null>(null);
  const [thumbError, setThumbError] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout>>(null);
  const pollRef = useRef<ReturnType<typeof setInterval>>(null);

  const detected = useMemo(() => detectPlatform(url), [url]);
  const platform = detected !== "unknown" ? PLATFORMS[detected] : null;

  const isValidUrl = useCallback((u: string) => {
    try {
      const parsed = new URL(u.trim());
      return parsed.protocol === "http:" || parsed.protocol === "https:";
    } catch {
      return false;
    }
  }, []);

  const valid = isValidUrl(url);

  // ── Auto-fetch metadata when URL changes ──
  useEffect(() => {
    if (!valid) {
      if (phase === "fetching-meta" || phase === "preview") {
        setPhase("idle");
        setMeta(null);
      }
      return;
    }

    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      setPhase("fetching-meta");
      setError(null);
      setMeta(null);
      setJob(null);
      setThumbError(false);

      try {
        const data = await fetchMetadata(url);
        if (data.status === "error") {
          setError(data.message || "Could not fetch video info.");
          setPhase("idle");
          return;
        }
        setMeta(data);
        // Auto-select best quality
        if (data.formats?.length > 0) {
          const best = data.formats.find((f: VideoFormat) => f.type === "video") || data.formats[0];
          if (best.height >= 1080) setSelectedQuality("1080");
          else setSelectedQuality(String(best.height || "720"));
        }
        setPhase("preview");
      } catch (err) {
        setError("Can't reach the server. Make sure Python backend is running (python app.py).");
        setPhase("idle");
      }
    }, 500);

    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [url, valid]);

  // ── Cleanup polling on unmount ──
  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text.trim());
    } catch {
      /* ignore */
    }
  };

  const handleDownload = async () => {
    if (!valid || !meta) return;
    setError(null);
    setPhase("downloading");

    try {
      const result = await startDownload(url, selectedQuality);
      if (result.status === "error") {
        setError(result.message || "Download failed.");
        setPhase("preview");
        return;
      }

      const jobId = result.job_id;
      if (!jobId) {
        setError("No job ID received.");
        setPhase("preview");
        return;
      }

      // Poll for progress
      setJob({ status: "downloading", progress: 0, message: "Starting download..." });

      pollRef.current = setInterval(async () => {
        try {
          const status = await pollJob(jobId);
          setJob(status);

          if (status.status === "done") {
            if (pollRef.current) clearInterval(pollRef.current);
            setPhase("done");

            // Auto-trigger download of the first file
            if (status.result?.files?.length) {
              const file = status.result.files[0];
              const fileUrl = getFileUrl(file.folder, file.name);
              triggerBrowserDownload(fileUrl, file.name);
            }
          } else if (status.status === "error") {
            if (pollRef.current) clearInterval(pollRef.current);
            setError(status.message || "Download failed.");
            setPhase("preview");
          }
        } catch {
          // Network error during poll — keep trying
        }
      }, 800);
    } catch {
      setError("Network error. Is the server running?");
      setPhase("preview");
    }
  };

  const reset = () => {
    if (pollRef.current) clearInterval(pollRef.current);
    setUrl("");
    setPhase("idle");
    setMeta(null);
    setError(null);
    setJob(null);
    setThumbError(false);
    inputRef.current?.focus();
  };

  // Build quality options from real format data
  const qualityOptions = useMemo(() => {
    if (!meta?.formats) return [];
    return meta.formats.map((f: VideoFormat) => ({
      ...f,
      selected: f.type === "video"
        ? String(f.height) === selectedQuality
        : selectedQuality === "audio",
    }));
  }, [meta, selectedQuality]);

  return (
    <section id="downloader" className="relative mx-auto w-full max-w-4xl px-5 pb-10 lg:px-8">
      <div className="glass-strong relative overflow-hidden rounded-3xl p-2 shadow-[0_40px_80px_-20px_rgba(124,58,237,0.35)]">
        <div className="pointer-events-none absolute inset-0 rounded-3xl bg-gradient-to-r from-violet-500/20 via-fuchsia-500/20 to-cyan-500/20 p-px" />

        <div className="relative rounded-[20px] bg-[#0a0a12] p-5 sm:p-7">
          {/* ─── URL Input ─── */}
          <div
            className={`group relative flex items-center overflow-hidden rounded-2xl border bg-white/[0.03] transition ${
              platform ? `border-white/15 ${platform.ring} ring-1` : "border-white/10"
            } focus-within:border-white/20`}
          >
            <div className="flex items-center gap-2 pl-4 text-zinc-400">
              {platform ? (
                <PlatformIcon platform={platform.icon} className="h-5 w-5" />
              ) : (
                <Link2 className="h-5 w-5" />
              )}
            </div>
            <input
              ref={inputRef}
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste any video link — YouTube, Instagram, TikTok, Twitter…"
              className="flex-1 bg-transparent px-3 py-4 text-sm text-white placeholder:text-zinc-500 focus:outline-none sm:text-base"
            />
            <div className="flex items-center gap-2 pr-2">
              {url && (
                <button
                  onClick={reset}
                  className="grid h-8 w-8 place-items-center rounded-lg text-zinc-500 hover:text-white transition"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
              <button
                type="button"
                onClick={handlePaste}
                className="hidden sm:inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs font-medium text-zinc-300 transition hover:bg-white/10"
              >
                <Copy className="h-3.5 w-3.5" />
                Paste
              </button>
            </div>
          </div>

          {/* ─── Examples ─── */}
          {phase === "idle" && !url && !error && (
            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-zinc-500">
              <span>Try:</span>
              {EXAMPLES.map((ex) => (
                <button
                  key={ex}
                  onClick={() => setUrl(ex)}
                  className="rounded-full border border-white/5 bg-white/[0.03] px-3 py-1 transition hover:border-white/15 hover:text-zinc-200"
                >
                  {ex.replace("https://www.", "").slice(0, 30)}…
                </button>
              ))}
            </div>
          )}

          {/* ─── Loading metadata ─── */}
          {phase === "fetching-meta" && (
            <div className="mt-6 flex items-center justify-center gap-3 py-12 text-sm text-zinc-400">
              <Loader2 className="h-5 w-5 animate-spin text-fuchsia-400" />
              Fetching video info with yt-dlp…
            </div>
          )}

          {/* ─── Error ─── */}
          {error && (
            <div className="mt-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
              <div className="flex items-start gap-2">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
                <div>
                  <p className="font-medium">{error}</p>
                  {error.includes("server") && (
                    <p className="mt-1 text-xs text-rose-300/70">
                      Run: <code className="rounded bg-black/30 px-1.5 py-0.5 font-mono">python app.py</code>
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ─── Video Preview + Quality ─── */}
          {(phase === "preview" || phase === "downloading" || phase === "done") && meta && (
            <div className="mt-6 fade-up">
              <div className="grid gap-5 sm:grid-cols-[280px_1fr]">
                {/* Thumbnail */}
                <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
                  <div className="aspect-video relative">
                    {meta.thumbnail && !thumbError ? (
                      <img
                        src={meta.thumbnail}
                        alt={meta.title}
                        className="h-full w-full object-cover"
                        onError={() => setThumbError(true)}
                      />
                    ) : (
                      <div
                        className={`h-full w-full bg-gradient-to-br ${
                          platform ? platform.gradient : "from-violet-600 to-fuchsia-600"
                        }`}
                      >
                        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_30%,rgba(0,0,0,0.5))]" />
                        <div className="absolute inset-0 grid place-items-center">
                          <FileVideo className="h-10 w-10 text-white/60" />
                        </div>
                      </div>
                    )}
                    {/* Platform badge */}
                    <div className="absolute top-2 left-2 inline-flex items-center gap-1.5 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-semibold text-white backdrop-blur">
                      {platform ? (
                        <PlatformIcon platform={platform.icon} className="h-3 w-3" />
                      ) : (
                        <span>{meta.platform_icon}</span>
                      )}
                      {meta.platform}
                    </div>
                    {/* Duration */}
                    {meta.duration && (
                      <div className="absolute bottom-2 right-2 inline-flex items-center gap-1 rounded-md bg-black/70 px-1.5 py-0.5 text-[10px] font-medium text-white backdrop-blur">
                        <Clock className="h-3 w-3" />
                        {meta.duration}
                      </div>
                    )}
                    {/* Download overlay */}
                    {phase === "downloading" && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm">
                        <div className="text-center">
                          <Loader2 className="mx-auto h-10 w-10 animate-spin text-fuchsia-400" />
                          <p className="mt-2 text-xs text-white/80">
                            {job?.progress || 0}%
                          </p>
                        </div>
                      </div>
                    )}
                    {phase === "done" && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm">
                        <div className="grid h-14 w-14 place-items-center rounded-full bg-emerald-500 shadow-lg shadow-emerald-500/30">
                          <Check className="h-7 w-7 text-white" strokeWidth={3} />
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Info + Quality Picker */}
                <div className="flex flex-col min-w-0">
                  <h3 className="text-base font-semibold text-white line-clamp-2 sm:text-lg">
                    {meta.title}
                  </h3>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-zinc-400">
                    {meta.author && <span className="font-medium text-zinc-300">{meta.author}</span>}
                    {meta.view_count ? (
                      <span className="inline-flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {formatViews(meta.view_count)}
                      </span>
                    ) : null}
                    {meta.duration && (
                      <span className="inline-flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {meta.duration}
                      </span>
                    )}
                  </div>

                  {/* Quality picker */}
                  {phase === "preview" && qualityOptions.length > 0 && (
                    <div className="mt-4 flex-1">
                      <p className="mb-2 text-xs font-medium text-zinc-400 uppercase tracking-wider">
                        Select quality
                      </p>
                      <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
                        {qualityOptions.map((opt) => {
                          const isAudio = opt.type === "audio";
                          const active = opt.selected;
                          return (
                            <button
                              key={opt.id + opt.label}
                              onClick={() =>
                                setSelectedQuality(isAudio ? "audio" : String(opt.height))
                              }
                              className={`relative flex items-center gap-2 rounded-xl border p-2.5 text-left text-xs transition ${
                                active
                                  ? "border-fuchsia-400/50 bg-fuchsia-400/10 text-white ring-1 ring-fuchsia-400/30"
                                  : "border-white/10 bg-white/[0.02] text-zinc-300 hover:bg-white/[0.05]"
                              }`}
                            >
                              {isAudio ? (
                                <Music
                                  className={`h-4 w-4 shrink-0 ${active ? "text-emerald-400" : "text-zinc-500"}`}
                                />
                              ) : (
                                <Film
                                  className={`h-4 w-4 shrink-0 ${active ? "text-fuchsia-400" : "text-zinc-500"}`}
                                />
                              )}
                              <div className="min-w-0">
                                <span className="font-medium block truncate">{opt.label}</span>
                                <span className="text-[10px] text-zinc-500 block">
                                  {opt.ext?.toUpperCase()}
                                  {opt.size ? ` · ${formatBytes(opt.size)}` : ""}
                                  {opt.fps ? ` · ${opt.fps}fps` : ""}
                                </span>
                              </div>
                              {opt.label === "1080p" && (
                                <span className="absolute -top-1.5 -right-1.5 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-1.5 py-0.5 text-[7px] font-bold uppercase text-zinc-900">
                                  HD
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Progress bar */}
                  {phase === "downloading" && job && (
                    <div className="mt-4 space-y-2">
                      <div className="flex items-center justify-between text-xs text-zinc-400">
                        <span className="inline-flex items-center gap-1.5 truncate">
                          <Loader2 className="h-3.5 w-3.5 animate-spin text-fuchsia-400 shrink-0" />
                          <span className="truncate">{job.message}</span>
                        </span>
                        <span className="shrink-0 ml-2">{job.progress}%</span>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-white/5">
                        <div
                          className="h-full bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 transition-all duration-300"
                          style={{ width: `${job.progress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Done state */}
                  {phase === "done" && job?.result && (
                    <div className="mt-4 space-y-3">
                      <div className="rounded-xl border border-emerald-400/30 bg-emerald-400/10 p-3">
                        <div className="flex items-center gap-2 text-sm text-emerald-200">
                          <Check className="h-4 w-4 text-emerald-400" strokeWidth={3} />
                          <span className="font-semibold">Download complete!</span>
                        </div>
                        {job.result.files.map((file, i) => (
                          <div
                            key={i}
                            className="mt-2 flex items-center justify-between gap-2 rounded-lg bg-black/20 px-3 py-2"
                          >
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-xs font-medium text-white">
                                {file.name}
                              </p>
                              <p className="text-[10px] text-zinc-500">
                                {formatBytes(file.size)}
                              </p>
                            </div>
                            <button
                              onClick={() =>
                                triggerBrowserDownload(
                                  getFileUrl(file.folder, file.name),
                                  file.name
                                )
                              }
                              className="inline-flex items-center gap-1 rounded-lg bg-white px-3 py-1.5 text-xs font-semibold text-zinc-900 hover:bg-zinc-200 transition shrink-0"
                            >
                              <ArrowDown className="h-3.5 w-3.5" />
                              Save
                            </button>
                          </div>
                        ))}
                      </div>
                      <button
                        onClick={reset}
                        className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-xs font-medium text-zinc-200 hover:bg-white/10 transition"
                      >
                        ← Download another video
                      </button>
                    </div>
                  )}

                  {/* Download button */}
                  {phase === "preview" && (
                    <button
                      onClick={handleDownload}
                      className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-fuchsia-500/25 transition hover:shadow-fuchsia-500/50 sm:w-auto"
                    >
                      <Download className="h-5 w-5" />
                      Download{" "}
                      {selectedQuality === "audio"
                        ? "Audio (MP3)"
                        : `${selectedQuality}p`}
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ─── Footer ─── */}
          <div className="mt-5 flex items-center gap-2 rounded-xl border border-white/5 bg-white/[0.02] p-3 text-[11px] text-zinc-500">
            <Sparkles className="h-4 w-4 shrink-0 text-fuchsia-400/60" />
            Powered by <strong className="text-zinc-300">yt-dlp</strong> — supports YouTube, Instagram, TikTok, Twitter/X, Reddit, Facebook & 1000+ sites.
          </div>
        </div>
      </div>
    </section>
  );
}
