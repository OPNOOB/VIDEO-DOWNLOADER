import type { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement>;

export function Logo(props: IconProps) {
  return (
    <svg viewBox="0 0 32 32" fill="none" {...props}>
      <defs>
        <linearGradient id="lg1" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#a78bfa" />
          <stop offset="50%" stopColor="#f0abfc" />
          <stop offset="100%" stopColor="#22d3ee" />
        </linearGradient>
      </defs>
      <path
        d="M6 10.5C6 8.5 7.6 7 9.6 7h8.8c2 0 3.6 1.5 3.6 3.5v3.5l4-2.3c1.2-.7 2.6.2 2.6 1.6v5.4c0 1.4-1.4 2.3-2.6 1.6l-4-2.3V21.5c0 2-1.6 3.5-3.6 3.5H9.6C7.6 25 6 23.5 6 21.5v-11z"
        fill="url(#lg1)"
      />
      <path d="M12 13v6l5-3-5-3z" fill="#0a0a0f" />
    </svg>
  );
}

export function YouTubeIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 0 0 .5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1c.5-1.9.5-5.8.5-5.8s0-3.9-.5-5.8zM9.6 15.6V8.4l6.3 3.6-6.3 3.6z" />
    </svg>
  );
}

export function InstagramIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function TikTokIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M19.6 6.3a4.8 4.8 0 0 1-3.4-1.5 4.8 4.8 0 0 1-1.2-3.3h-3.3v12.4a2.7 2.7 0 1 1-2.7-2.7c.3 0 .6 0 .9.1V7.9a6 6 0 1 0 5.1 6V9.3a8 8 0 0 0 4.6 1.5V7.5c-.4 0-.8-.1-1.2-.2a4.7 4.7 0 0 1-1.2-.4V6.3z" />
    </svg>
  );
}

export function PlatformIcon({ platform, ...props }: { platform: "youtube" | "instagram" | "tiktok" } & IconProps) {
  if (platform === "youtube") return <YouTubeIcon {...props} />;
  if (platform === "instagram") return <InstagramIcon {...props} />;
  return <TikTokIcon {...props} />;
}
