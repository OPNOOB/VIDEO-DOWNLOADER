import { useEffect, useRef, useState } from "react";
import { useInView } from "../hooks/useInView";
import { Download, Globe, Users, Zap } from "lucide-react";

interface StatItem {
  icon: typeof Download;
  value: number;
  suffix: string;
  label: string;
  accent: string;
}

const STATS: StatItem[] = [
  { icon: Download, value: 842, suffix: "M+", label: "Videos downloaded", accent: "from-violet-500 to-fuchsia-500" },
  { icon: Users, value: 12, suffix: "M+", label: "Happy users", accent: "from-pink-500 to-rose-500" },
  { icon: Globe, value: 190, suffix: "+", label: "Countries served", accent: "from-cyan-400 to-sky-500" },
  { icon: Zap, value: 99.9, suffix: "%", label: "Uptime SLA", accent: "from-emerald-400 to-teal-500" },
];

function AnimatedNumber({ target, inView }: { target: number; inView: boolean }) {
  const [val, setVal] = useState(0);
  const started = useRef(false);
  useEffect(() => {
    if (!inView || started.current) return;
    started.current = true;
    const duration = 1800;
    const start = performance.now();
    const step = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(target * eased);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [inView, target]);

  const formatted =
    target % 1 === 0 ? Math.floor(val).toLocaleString() : val.toFixed(1);
  return <>{formatted}</>;
}

export function Stats() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <section className="relative py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div
          ref={ref}
          className="glass-strong relative overflow-hidden rounded-3xl p-8 sm:p-12"
        >
          <div className="absolute -top-32 left-1/2 h-64 w-[120%] -translate-x-1/2 rounded-full bg-gradient-to-r from-violet-500/30 via-fuchsia-500/30 to-cyan-500/30 blur-3xl" />
          <div className="relative grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {STATS.map((s) => (
              <div key={s.label} className="text-center">
                <div
                  className={`mx-auto grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br ${s.accent} shadow-lg`}
                >
                  <s.icon className="h-6 w-6 text-white" />
                </div>
                <div className="mt-4 text-4xl font-bold tracking-tight text-white sm:text-5xl">
                  <AnimatedNumber target={s.value} inView={inView} />
                  <span className="text-gradient">{s.suffix}</span>
                </div>
                <p className="mt-1 text-sm text-zinc-400">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
