import { Downloader } from "./Downloader";
import { ArrowRight, BadgeCheck, Download, Sparkles, Star, TrendingUp } from "lucide-react";

const TRUST = [
  { icon: BadgeCheck, label: "No watermark" },
  { icon: TrendingUp, label: "4K supported" },
  { icon: Download, label: "Unlimited downloads" },
  { icon: Sparkles, label: "Free forever" },
];

export function Hero() {
  return (
    <section className="relative overflow-hidden pt-14 pb-6 sm:pt-20">
      {/* Background layers */}
      <div className="absolute inset-0 grid-bg opacity-60" />
      <div className="aurora">
        <div className="aurora-extra" />
      </div>

      <div className="relative mx-auto flex max-w-7xl flex-col items-center text-center">
        {/* Badge */}
        <div className="fade-up mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-1.5 text-xs font-medium text-zinc-300 backdrop-blur">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
          </span>
          New · Bulk playlist downloads now available
          <ArrowRight className="h-3 w-3" />
        </div>

        {/* Headline */}
        <h1
          className="fade-up max-w-4xl text-balance text-4xl font-bold leading-[1.05] tracking-tight text-white sm:text-5xl lg:text-7xl"
          style={{ animationDelay: "0.08s" }}
        >
          Download any video,
          <br />
          <span className="text-gradient">from any platform</span>, in
          <br className="hidden sm:block" /> crystal‑clear quality.
        </h1>

        <p
          className="fade-up mt-6 max-w-2xl text-balance text-base text-zinc-400 sm:text-lg"
          style={{ animationDelay: "0.16s" }}
        >
          Paste a link. Pick a format. Done. Powered by yt-dlp, Snatch downloads from YouTube,
          Instagram, TikTok, Twitter & 1000+ sites — runs 100% on your machine.
        </p>

        {/* CTA row */}
        <div
          className="fade-up mt-8 flex flex-wrap items-center justify-center gap-3"
          style={{ animationDelay: "0.22s" }}
        >
          <a
            href="#downloader"
            className="group relative inline-flex items-center gap-2 overflow-hidden rounded-full bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-fuchsia-500/25 transition hover:shadow-fuchsia-500/50"
          >
            <Download className="h-4 w-4" />
            Start downloading — it's free
            <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
          </a>
          <a
            href="#how"
            className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-6 py-3 text-sm font-semibold text-zinc-200 backdrop-blur transition hover:bg-white/10"
          >
            See how it works
          </a>
        </div>

        {/* Trust row */}
        <div
          className="fade-up mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-xs text-zinc-400"
          style={{ animationDelay: "0.3s" }}
        >
          {TRUST.map(({ icon: Icon, label }) => (
            <span key={label} className="inline-flex items-center gap-1.5">
              <Icon className="h-3.5 w-3.5 text-emerald-400" />
              {label}
            </span>
          ))}
        </div>

        {/* Rating */}
        <div
          className="fade-up mt-4 inline-flex items-center gap-2 text-xs text-zinc-400"
          style={{ animationDelay: "0.36s" }}
        >
          <div className="flex items-center gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
            ))}
          </div>
          <span>
            <strong className="text-zinc-200">4.9/5</strong> from 48,000+ creators
          </span>
        </div>
      </div>

      {/* Downloader */}
      <div className="fade-up relative mt-12" style={{ animationDelay: "0.4s" }}>
        <Downloader />
      </div>

      {/* Social proof strip */}
      <div className="relative mx-auto mt-16 max-w-5xl px-5">
        <p className="mb-6 text-center text-[11px] uppercase tracking-[0.2em] text-zinc-500">
          Trusted by creators at
        </p>
        <div className="relative overflow-hidden">
          <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-[#06060a] to-transparent z-10" />
          <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-[#06060a] to-transparent z-10" />
          <div className="marquee-track flex w-max gap-12">
            {[...Array(2)].map((_, loop) => (
              <div key={loop} className="flex items-center gap-12 pr-12">
                {["PULSE", "NORTHWIND", "VERTEX", "LUMEN", "QUANTA", "ORBITAL", "KAIROS", "HELIX"].map((b) => (
                  <span key={b + loop} className="text-xl font-bold tracking-[0.2em] text-zinc-600">
                    {b}
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

