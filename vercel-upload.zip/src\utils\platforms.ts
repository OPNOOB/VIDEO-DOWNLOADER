export type PlatformId = "youtube" | "instagram" | "tiktok" | "unknown";

export interface Platform {
  id: PlatformId;
  name: string;
  tagline: string;
  gradient: string;
  ring: string;
  accent: string;
  text: string;
  icon: "youtube" | "instagram" | "tiktok";
  supported: string[];
}

export const PLATFORMS: Record<Exclude<PlatformId, "unknown">, Platform> = {
  youtube: {
    id: "youtube",
    name: "YouTube",
    tagline: "Videos, Shorts & Playlists",
    gradient: "from-rose-500 via-red-500 to-orange-500",
    ring: "ring-rose-400/40",
    accent: "#ff4444",
    text: "text-rose-300",
    icon: "youtube",
    supported: ["MP4 up to 4K", "MP3 up to 320kbps", "Captions (SRT)"],
  },
  instagram: {
    id: "instagram",
    name: "Instagram",
    tagline: "Reels, Posts & Stories",
    gradient: "from-fuchsia-500 via-pink-500 to-orange-400",
    ring: "ring-fuchsia-400/40",
    accent: "#e1306c",
    text: "text-fuchsia-300",
    icon: "instagram",
    supported: ["Reels 1080p", "IGTV", "Story & Post media"],
  },
  tiktok: {
    id: "tiktok",
    name: "TikTok",
    tagline: "Videos, no watermark",
    gradient: "from-cyan-400 via-sky-500 to-violet-500",
    ring: "ring-cyan-400/40",
    accent: "#25f4ee",
    text: "text-cyan-300",
    icon: "tiktok",
    supported: ["No watermark", "HD 1080p", "Audio extraction"],
  },
};

const PATTERNS: Array<{ pattern: RegExp; id: Exclude<PlatformId, "unknown"> }> = [
  { pattern: /(?:youtube\.com|youtu\.be|youtube-nocookie\.com)/i, id: "youtube" },
  { pattern: /(?:instagram\.com|instagr\.am)/i, id: "instagram" },
  { pattern: /(?:tiktok\.com|vm\.tiktok\.com|vt\.tiktok\.com)/i, id: "tiktok" },
];

export function detectPlatform(url: string): PlatformId {
  const trimmed = url.trim();
  if (!trimmed) return "unknown";
  for (const { pattern, id } of PATTERNS) {
    if (pattern.test(trimmed)) return id;
  }
  return "unknown";
}

export function isValidUrl(url: string): boolean {
  try {
    const u = new URL(url.trim());
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}
