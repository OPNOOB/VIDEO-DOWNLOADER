import { useState } from "react";
import { ChevronDown, MessageCircleQuestion } from "lucide-react";

const FAQS = [
  {
    q: "Is Snatch really free?",
    a: "Yes — 100% free, open‑source, and runs on your own machine. There are no premium tiers, no limits, and no ads. It's powered by yt-dlp under the hood.",
  },
  {
    q: "How does it work?",
    a: "Snatch uses yt-dlp, the most powerful open‑source video downloader. When you paste a link, yt-dlp fetches metadata (title, thumbnail, available qualities) and then downloads the video directly to your computer. Everything runs locally — nothing goes through external servers.",
  },
  {
    q: "What do I need to install?",
    a: "Python 3.8+ and Node.js. Then just run 'pip install -r requirements.txt' and 'python app.py'. On Windows, you can double-click run.bat and it sets everything up automatically.",
  },
  {
    q: "Which platforms are supported?",
    a: "YouTube, Instagram (Reels, Stories, Posts), TikTok, Twitter/X, Facebook, Reddit, Twitch, Vimeo, Pinterest, LinkedIn, Dailymotion, SoundCloud, and 1000+ other sites — anything yt-dlp supports.",
  },
  {
    q: "Which video qualities are supported?",
    a: "Every quality the source offers — from 144p to 4K/8K on YouTube. The quality picker shows exactly what's available, including file sizes. You can also extract audio-only as MP3 at 320kbps.",
  },
  {
    q: "Where do downloaded files go?",
    a: "Files are saved to a 'downloads' folder in the project directory, organized by platform and timestamp. You can also click the Save button to download them directly to your browser's Downloads folder.",
  },
  {
    q: "Are my downloads private?",
    a: "Completely. Everything runs on YOUR computer. No data is sent to any external server. No analytics, no tracking, no logs. The Python server only runs locally on localhost.",
  },
];

function FaqItem({ q, a, open, toggle }: { q: string; a: string; open: boolean; toggle: () => void }) {
  return (
    <div
      className={`rounded-2xl border transition ${
        open ? "border-white/20 bg-white/[0.04]" : "border-white/10 bg-white/[0.02]"
      }`}
    >
      <button
        onClick={toggle}
        className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
      >
        <span className="text-sm font-medium text-white sm:text-base">{q}</span>
        <ChevronDown
          className={`h-5 w-5 shrink-0 text-zinc-400 transition ${open ? "rotate-180 text-white" : ""}`}
        />
      </button>
      <div
        className={`grid transition-all ${open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}
      >
        <div className="overflow-hidden">
          <p className="px-5 pb-5 text-sm leading-relaxed text-zinc-400">{a}</p>
        </div>
      </div>
    </div>
  );
}

export function FAQ() {
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  return (
    <section id="faq" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-3xl px-5 lg:px-8">
        <div className="text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-medium uppercase tracking-widest text-zinc-400">
            <MessageCircleQuestion className="h-3 w-3 text-fuchsia-400" />
            FAQ
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-white sm:text-5xl">
            Questions? <span className="text-gradient">We've got answers.</span>
          </h2>
          <p className="mt-4 text-base text-zinc-400 sm:text-lg">
            Can't find what you're looking for? <a href="#" className="text-fuchsia-300 hover:underline">Chat with us →</a>
          </p>
        </div>

        <div className="mt-12 space-y-3">
          {FAQS.map((f, idx) => (
            <FaqItem
              key={f.q}
              q={f.q}
              a={f.a}
              open={openIdx === idx}
              toggle={() => setOpenIdx(openIdx === idx ? null : idx)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
