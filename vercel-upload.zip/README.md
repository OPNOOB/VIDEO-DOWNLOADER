# Snatch — Universal Video Downloader

Download videos from **YouTube, Instagram, TikTok, Twitter/X, Facebook, Reddit** & 1000+ sites.  
Powered by **yt-dlp**. Runs 100% locally on your machine. No external APIs.

---

## 🚀 Quick Start (Windows — double-click)

1. Make sure Python & Node.js are installed  
2. Double-click **`run.bat`**  
3. Open **http://localhost:5000**

---

## 🚀 Quick Start (Manual)

```bash
# 1. Install Python dependencies
pip install -r requirements.txt

# 2. Build the frontend (once)
npm install
npm run build

# 3. Run the server
python app.py
```

Open **http://localhost:5000** → paste any video link → pick quality → download.

---

## 📋 How It Works

```
┌─────────────────┐     ┌──────────────┐     ┌──────────┐
│  React Frontend  │────▶│  Flask API   │────▶│  yt-dlp  │
│  (your browser)  │◀────│  (Python)    │◀────│  (local) │
└─────────────────┘     └──────────────┘     └──────────┘
```

1. **Paste a URL** — the frontend detects the platform (YouTube/Instagram/TikTok/etc.)
2. **Auto-fetch metadata** — Flask calls yt-dlp to get title, thumbnail, available qualities
3. **Pick quality** — real format list from yt-dlp (4K, 1080p, 720p, Audio MP3, etc.)
4. **Download** — yt-dlp downloads the video locally, with real-time progress
5. **Save file** — browser auto-downloads the file to your Downloads folder

---

## 📂 Where Are My Downloads?

Files are saved to `./downloads/` in the project folder, organized by platform and timestamp.

---

## 🌐 Supported Platforms

| Platform | Videos | Audio | Status |
|----------|--------|-------|--------|
| YouTube | ✅ up to 8K | ✅ MP3 320kbps | Full support |
| Instagram | ✅ Reels, Posts, Stories | ✅ | Full support |
| TikTok | ✅ No watermark | ✅ | Full support |
| Twitter/X | ✅ | ✅ | Full support |
| Facebook | ✅ | ❌ | Videos only |
| Reddit | ✅ | ✅ | Full support |
| Twitch | ✅ Clips | ✅ | Clips only |
| Vimeo | ✅ | ✅ | Full support |
| + 1000 more | ✅ | ✅ | Via yt-dlp |

---

## 🛠 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/metadata` | POST | Fetch video info (title, thumbnail, formats) |
| `/api/download` | POST | Start download with selected quality |
| `/api/job/<id>` | GET | Poll download progress |
| `/api/file/<folder>/<name>` | GET | Download a completed file |
| `/api/downloads` | GET | List all downloads |
| `/api/clear-downloads` | POST | Clear all downloaded files |
| `/api/platforms` | GET | List supported platforms |

---

## ❓ Troubleshooting

| Problem | Fix |
|---------|-----|
| `ModuleNotFoundError: yt_dlp` | Run `pip install -r requirements.txt` |
| Frontend shows "Can't reach server" | Make sure `python app.py` is running |
| `npm run build` fails | Run `npm install` first |
| Video quality not available | Not all videos have all qualities |
| Age-restricted YouTube | Not supported without cookies |
| Private/login-only content | Only public content works |

---

## 📁 Project Structure

```
├── app.py                 ← Python backend (Flask + yt-dlp)
├── requirements.txt       ← Python dependencies
├── run.bat               ← Windows one-click launcher
├── run.sh                ← Linux/Mac launcher
├── downloads/            ← Downloaded files go here
├── dist/                 ← Built frontend (served by Flask)
└── src/
    ├── App.tsx
    ├── components/
    │   ├── Downloader.tsx    ← Main download UI
    │   ├── Navbar / Hero / Features / etc.
    │   └── Icons.tsx
    ├── lib/
    │   └── api.ts           ← API client for Flask backend
    └── utils/
        └── platforms.ts     ← URL detection
```

Built with React 19 + Vite + Tailwind CSS v4 + Flask + yt-dlp.
