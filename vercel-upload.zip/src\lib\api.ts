/**
 * API client for the Flask + yt-dlp backend running on localhost:5000
 */

const API = (() => {
  // Dev: Vite on :5173, Flask on :5000
  // Prod: Flask serves both on :5000
  if (typeof window !== "undefined" && window.location.port === "5173") {
    return "http://localhost:5000";
  }
  return "";
})();

// ─── Types ───────────────────────────────────────────────────────────────────

export interface VideoFormat {
  id: string;
  label: string;
  height: number;
  ext: string;
  type: "video" | "audio";
  size: number | null;
  fps?: number;
  vcodec?: string;
}

export interface VideoMeta {
  status: "success" | "error";
  title: string;
  author: string;
  thumbnail: string | null;
  duration: string | null;
  view_count: number | null;
  platform: string;
  platform_icon: string;
  formats: VideoFormat[];
  webpage_url: string;
  message?: string;
}

export interface DownloadJob {
  status: "downloading" | "done" | "error" | "started";
  progress: number;
  message: string;
  url?: string;
  platform?: string;
  result?: {
    title: string;
    author: string;
    files: Array<{ name: string; path: string; size: number; folder: string }>;
    folder: string;
  };
  job_id?: string;
}

// ─── API calls ───────────────────────────────────────────────────────────────

export async function fetchMetadata(url: string): Promise<VideoMeta> {
  const res = await fetch(`${API}/api/metadata`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url }),
  });
  return res.json();
}

export async function startDownload(url: string, quality: string): Promise<{ status: string; job_id?: string; message?: string }> {
  const res = await fetch(`${API}/api/download`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url, quality }),
  });
  return res.json();
}

export async function pollJob(jobId: string): Promise<DownloadJob> {
  const res = await fetch(`${API}/api/job/${jobId}`);
  return res.json();
}

export function getFileUrl(folder: string, filename: string): string {
  return `${API}/api/file/${encodeURIComponent(folder)}/${encodeURIComponent(filename)}`;
}

export function getFolderZipUrl(folder: string): string {
  return `${API}/api/folder/${encodeURIComponent(folder)}`;
}

export function triggerBrowserDownload(url: string, filename?: string) {
  const a = document.createElement("a");
  a.href = url;
  a.rel = "noopener noreferrer";
  if (filename) a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

export function formatBytes(bytes: number | null): string {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} MB`;
  return `${(bytes / 1073741824).toFixed(2)} GB`;
}

export function formatViews(n: number | null): string {
  if (!n) return "";
  if (n >= 1e9) return `${(n / 1e9).toFixed(1)}B views`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M views`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K views`;
  return `${n} views`;
}
