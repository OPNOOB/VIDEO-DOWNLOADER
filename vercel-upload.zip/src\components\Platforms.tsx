import { PLATFORMS } from "../utils/platforms";
import { PlatformIcon } from "./Icons";
import { useInView } from "../hooks/useInView";
import { Check } from "lucide-react";

export function Platforms() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <section id="platforms" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-medium uppercase tracking-widest text-zinc-400">
            Platforms
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-white sm:text-5xl">
            One tool.{" "}
            <span className="text-gradient">Every video platform</span> you love.
          </h2>
          <p className="mt-4 text-base text-zinc-400 sm:text-lg">
            Optimized for the Big Three — and always expanding.
          </p>
        </div>

        <div ref={ref} className="mt-14 grid gap-5 md:grid-cols-3">
          {(Object.keys(PLATFORMS) as Array<keyof typeof PLATFORMS>).map((key, idx) => {
            const p = PLATFORMS[key];
            return (
              <div
                key={key}
                className={`group relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.02] p-7 transition hover:border-white/20 ${
                  inView ? "fade-up" : "opacity-0"
                }`}
                style={{ animationDelay: `${idx * 120}ms` }}
              >
                {/* Background gradient */}
                <div
                  className={`absolute -top-32 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full bg-gradient-to-br ${p.gradient} opacity-20 blur-3xl transition group-hover:opacity-40`}
                />

                <div className="relative">
                  <div
                    className={`inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${p.gradient} text-white shadow-lg`}
                  >
                    <PlatformIcon platform={p.icon} className="h-7 w-7" />
                  </div>

                  <h3 className="mt-5 text-xl font-bold text-white">{p.name}</h3>
                  <p className="text-sm text-zinc-400">{p.tagline}</p>

                  <ul className="mt-5 space-y-2">
                    {p.supported.map((item) => (
                      <li
                        key={item}
                        className="flex items-center gap-2 text-sm text-zinc-300"
                      >
                        <div className={`grid h-5 w-5 place-items-center rounded-full bg-gradient-to-br ${p.gradient}`}>
                          <Check className="h-3 w-3 text-white" strokeWidth={3} />
                        </div>
                        {item}
                      </li>
                    ))}
                  </ul>

                  <a
                    href="#downloader"
                    className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-zinc-200 transition group-hover:text-white"
                  >
                    Try it
                    <span className="transition group-hover:translate-x-0.5">→</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
